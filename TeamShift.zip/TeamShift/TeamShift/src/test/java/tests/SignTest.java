package tests;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.concurrent.TimeUnit;
public class SignTest {
    private FirefoxDriver browser;
    @Test
    public void testSignInTeamShift() {
        System.setProperty("webdriver.firefox.driver", "C:\\geckodriver.exe");
        browser = new FirefoxDriver();
        browser.manage().window().maximize();
        WebDriverWait wait = new WebDriverWait(browser, 15);
        browser.get("https://teamshift-qa.crossknowledge.com");
        browser.findElement(By.xpath("//button")).click();
        browser.findElement(By.xpath("//input[@id='login-form__login']")).sendKeys("alinedpvasconcelos@gmail.com");
        browser.findElement(By.xpath("/html/body/main/div[5]/div/div/div[3]/button[2]")).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@id='login-form__password']")));
        browser.findElement(By.xpath("//input[@id='login-form__password']")).sendKeys("WLS2020qa");
        browser.findElement(By.xpath("/html/body/main/div[5]/div/div/div[3]/button[2]")).click();
    }
}





